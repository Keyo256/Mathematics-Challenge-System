package com.learning.Client;


import org.json.JSONObject;

import java.util.Scanner;

public class Converter {
    User user;

    public Converter(User user) {
        this.user = user;
    }
    public String viewApplicants() {
        JSONObject obj = new JSONObject();
        obj.put("command", "viewApplicants");
        obj.put("isAuthenticated", this.user.isAuthenticated);
        obj.put("isStudent", this.user.isStudent);
        obj.put("regNo", this.user.regNo);


        return obj.toString(4);
    }

    public String confirm(String[] arr) {
        JSONObject obj = new JSONObject();
        obj.put("command", "confirm");
        obj.put("username", arr[2]);
        obj.put("regNo", this.user.regNo);
        obj.put("confirm", (arr[1].toLowerCase().equals("yes")) ? true : false);
        obj.put("tokens", arr);

        return obj.toString(4);
    }



        return obj.toString(4);
    }

    public String logout() {
        this.user.logout();
        return "Successfully logged out";
    }

    public String serialize(String command) {
        String[] tokens = command.split("\\s+");

        if (!user.isAuthenticated && tokens[0].equals("register")) {
            return this.register(tokens);
        }

        if (!user.isAuthenticated && tokens[0].equals("login")) {
            return this.login();
        }

        if (!user.isAuthenticated) {
            return "Session unauthenticated first login by entering command login";
        }

        if (user.isStudent) {
            switch (tokens[0]) {

                default:
                    return "Invalid student command";
            }
        } else {
            switch (tokens[0]) {
                case "logout":
                    return this.logout();

                case "confirm":
                    return this.confirm(tokens);

                case "viewApplicants":
                    return this.viewApplicants();

                default:
                    return "Invalid school representative command";
            }
        }

    }

    public static void main (String[] args) {
        Converter sample = new Converter(new User());
        sample.serialize("login frank ogenrwothjimfrank@gmail.com");
}

