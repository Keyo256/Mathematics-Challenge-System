package com.learning.Client;

public class User {
    String username;
    String regNo;
    boolean isverified =false;
    String output;
    public void login(String username,String regNo,boolean isverified){
     this.username = username;
     this.regNo=regNo;
     this.isverified = true;
    }
    public void logout(){
        this.username ="";
        this.regNo ="";
        this.isverified=false;
    }
}
